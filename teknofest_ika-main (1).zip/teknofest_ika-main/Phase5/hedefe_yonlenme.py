#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import Float32, String
import math

class GoalNavigatorNode(Node):
    def __init__(self):
        super().__init__('goal_navigator_node')

        # Subscriptions
        self.create_subscription(NavSatFix, 'gps_position', self.gps_callback, 10)
        self.create_subscription(Float32, 'imu_heading', self.imu_callback, 10)

        # Publisher for navigation command
        self.command_pub = self.create_publisher(String, 'navigation_command', 10)

        # Goal location (example: Yıldız Teknik Üniversitesi)
        self.target_lat = 41.0256
        self.target_lon = 28.8883

        self.current_lat = None
        self.current_lon = None
        self.current_heading = None

        self.get_logger().info("Goal navigator node started.")

    def gps_callback(self, msg):
        self.current_lat = msg.latitude
        self.current_lon = msg.longitude
        self.navigate_if_ready()

    def imu_callback(self, msg):
        self.current_heading = msg.data
        self.navigate_if_ready()

    def navigate_if_ready(self):
        if None in (self.current_lat, self.current_lon, self.current_heading):
            return  # Wait until all data is available

        # Calculate target bearing
        bearing = self.calculate_bearing(
            self.current_lat, self.current_lon,
            self.target_lat, self.target_lon
        )

        # Compare with heading
        angle_diff = (bearing - self.current_heading + 360) % 360
        if angle_diff > 180:
            angle_diff -= 360  # Normalize to [-180, 180]

        # Decide action
        command = String()
        if abs(angle_diff) < 10:
            command.data = "FORWARD"
        elif angle_diff > 0:
            command.data = "TURN_RIGHT"
        else:
            command.data = "TURN_LEFT"

        self.command_pub.publish(command)
        self.get_logger().info(
            f"[Navi] Pos: ({self.current_lat:.5f}, {self.current_lon:.5f}) | "
            f"Head: {self.current_heading:.2f}° | "
            f"Bearing: {bearing:.2f}° | "
            f"Action: {command.data}"
        )

    def calculate_bearing(self, lat1, lon1, lat2, lon2):
        # Convert to radians
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
        d_lon = lon2 - lon1

        x = math.sin(d_lon) * math.cos(lat2)
        y = math.cos(lat1) * math.sin(lat2) - (
            math.sin(lat1) * math.cos(lat2) * math.cos(d_lon)
        )

        bearing = math.degrees(math.atan2(x, y))
        return (bearing + 360) % 360

def main(args=None):
    rclpy.init(args=args)
    node = GoalNavigatorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Goal navigator node stopped.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
