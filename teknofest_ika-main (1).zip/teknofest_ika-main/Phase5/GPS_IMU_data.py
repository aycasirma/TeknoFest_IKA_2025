#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import Float32
import random

class SimulatedGpsImuNode(Node):
    def __init__(self):
        super().__init__('simulated_gps_imu_node')

        self.gps_pub = self.create_publisher(NavSatFix, 'gps_position', 10)
        self.heading_pub = self.create_publisher(Float32, 'imu_heading', 10)

        self.lat = 41.0082
        self.lon = 28.9784
        self.heading = 0.0

        self.create_timer(1.0, self.update_data)
        self.get_logger().info("Simulated GPS + IMU node started.")

    def update_data(self):
        self.lat += random.uniform(-0.00005, 0.00005)
        self.lon += random.uniform(-0.00005, 0.00005)
        self.heading = (self.heading + random.uniform(-5, 5)) % 360

        gps_msg = NavSatFix()
        gps_msg.latitude = round(self.lat, 6)
        gps_msg.longitude = round(self.lon, 6)
        gps_msg.altitude = 33.3
        self.gps_pub.publish(gps_msg)

        heading_msg = Float32()
        heading_msg.data = round(self.heading, 2)
        self.heading_pub.publish(heading_msg)

        self.get_logger().info(f"[GPS] Lat: {gps_msg.latitude}, Lon: {gps_msg.longitude}")
        self.get_logger().info(f"[IMU] Heading: {heading_msg.data:.2f}°")

def main(args=None):
    rclpy.init(args=args)
    node = SimulatedGpsImuNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Simulated GPS + IMU node stopped.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
