servo_motor.py Dosyasını Çalıştırın:

Python 3 ile servo_motor.py dosyasını çalıştırın.

Bu dosya, servo motorları simüle edecektir.

Komutları Girin:

Komut istemine aşağıdaki komutları yazabilirsiniz:

AIM = 1: Hedefi belirli bir açıya yönlendirir.

FIRE_ANGLE = 2: Atış açısını ayarlar.

FIRE = 3: Ateş eder.

EXIT = 4: Simülasyonu durdurur.

Simülasyonun Kaydını Yapın:

Her komut sonrası, servo motorların hareketleri kaydedilecektir.

Kaydedilen dosya: servo_motor_log.csv

Bu dosya, hareketlerin zamanını ve hangi komutların verildiğini gösterir.

CSV Dosyasındaki Bilgiler:

Zaman (Time(s)): Komutun verildiği saniye.

Komut (Command): Verilen komut (AIM, FIRE_ANGLE, FIRE).

Servo Motor Açısı (Angle): Motorun döndüğü açı.

Açıklama (Description): Yapılan hareketin açıklaması.
