import time

# Servo simülasyonu için GPIO sınıfı
class GPIO:
    OUT = 0
    HIGH = 1
    LOW = 0
    BOARD = 1
    BCM = 2

    def __init__(self):
        self.pins = {}
        self.mode = None

    def setmode(self, mode):
        self.mode = mode
        print(f"Pin numaralandırma modu: {mode}")

    def setup(self, pin, mode):
        self.pins[pin] = 0
        print(f"Pin {pin} çıkış olarak ayarlandı.")

    def output(self, pin, value):
        print(f"Pin {pin} çıkışı {value} olarak ayarlandı.")

    def cleanup(self):
        print("GPIO temizlendi.")

# GPIO'yu başlat
GPIO = GPIO()

class ServoMotor:
    def __init__(self, pin, name):
        self.pin = pin
        self.name = name
        self.angle = 90  # Başlangıç açısı (orta konum)

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.pin, GPIO.OUT)
        print(f"{self.name} servo motoru başlatıldı. Başlangıç açısı: {self.angle} derece")

    def rotate_to(self, angle):
        if 0 <= angle <= 180:
            self.angle = angle
            print(f"{self.name} servo motoru {angle} dereceye döndü (simülasyon).")
        else:
            print("Geçersiz açı. 0 ile 180 derece arasında olmalı.")

class FireControlSystem:
    def __init__(self):
        print("Atış Kontrol Sistemi başlatıldı.")
        self.target_servo = ServoMotor(pin=12, name="Hedef Yönlendirme")
        self.fire_servo = ServoMotor(pin=13, name="Atış Mekanizması")

    def aim_target(self, angle):
        print("Hedef yönlendirme komutu alındı.")
        self.target_servo.rotate_to(angle)

    def adjust_fire_angle(self, angle):
        print("Atış açısı ayarlanıyor.")
        self.fire_servo.rotate_to(angle)

    def fire(self):
        print("Ateşleme başlatılıyor...")
        self.fire_servo.rotate_to(60)  # Atış pozisyonuna getir
        time.sleep(1)
        self.fire_servo.rotate_to(90)  # Başlangıç pozisyonuna dön
        print("Ateş tamamlandı.")

    def run(self):
        try:
            while True:
                command = input("Komut gir (AIM(1)/FIRE_ANGLE(2)/FIRE(3)/EXIT(4)): ").upper()

                if command == "1":
                    angle = int(input("Hedef açısını gir (0-180): "))
                    self.aim_target(angle)

                elif command == "2":
                    angle = int(input("Atış açısını gir (0-180): "))
                    self.adjust_fire_angle(angle)

                elif command == "3":
                    self.fire()

                elif command == "4":
                    break

                else:
                    print("Geçersiz komut.")
        except KeyboardInterrupt:
            print("\nSimülasyon durduruldu.")
        finally:
            GPIO.cleanup()

if __name__ == "__main__":
    system = FireControlSystem()
    system.run()