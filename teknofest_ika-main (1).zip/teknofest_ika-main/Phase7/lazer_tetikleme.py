#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool
import re

class LaserTriggerNode(Node):
    def __init__(self):
        super().__init__('laser_trigger_node')

        self.subscription = self.create_subscription(
            String,
            'detected_target',
            self.target_callback,
            10
        )
        self.laser_pub = self.create_publisher(Bool, 'laser_status', 10)

        self.frame_center = 320
        self.center_tolerance = 30  # ±30px

        self.get_logger().info("Laser trigger node started.")

    def target_callback(self, msg):
        # Extract x coordinate from detection message
        match = re.search(r'\((\d+),\s*(\d+)\)', msg.data)
        if not match:
            self.get_logger().warn("Invalid detection format.")
            return

        x = int(match.group(1))
        centered = abs(x - self.frame_center) <= self.center_tolerance

        laser_msg = Bool()
        laser_msg.data = centered
        self.laser_pub.publish(laser_msg)

        if centered:
            self.get_logger().info(f"Target centered at x={x} → LASER ON ✅")
        else:
            self.get_logger().info(f"Target at x={x} → LASER OFF ❌")

def main(args=None):
    rclpy.init(args=args)
    node = LaserTriggerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Laser trigger node stopped.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

