#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool

class LaserSafetyNode(Node):
    def __init__(self):
        super().__init__('laser_safety_node')

        self.subscription = self.create_subscription(
            Bool,
            'laser_status',
            self.laser_status_callback,
            10
        )

        self.safe_pub = self.create_publisher(Bool, 'safe_laser_fire', 10)

        self.confirmation_count = 0
        self.required_confirmations = 3

        self.get_logger().info("Laser safety control node started.")

    def laser_status_callback(self, msg: Bool):
        if msg.data:  # Target centered
            self.confirmation_count += 1
            self.get_logger().info(f"Centered: {self.confirmation_count} / {self.required_confirmations}")
        else:
            self.confirmation_count = 0  # Reset if not stable

        fire_msg = Bool()
        fire_msg.data = self.confirmation_count >= self.required_confirmations
        self.safe_pub.publish(fire_msg)

        if fire_msg.data:
            self.get_logger().info("✅ Safe fire condition met. FIRE!")
        else:
            self.get_logger().info("❌ Not safe to fire.")

def main(args=None):
    rclpy.init(args=args)
    node = LaserSafetyNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Laser safety node stopped.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
