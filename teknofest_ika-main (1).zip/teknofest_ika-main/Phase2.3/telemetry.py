import time
import random
import csv
from datetime import datetime

class VehicleStatusSimulator:
    def __init__(self):
        # Başlangıç koordinatları (örnek olarak İstanbul civarı)
        self.latitude = 41.0082  # enlem
        self.longitude = 28.9784  # boylam
        self.heading = 0  # yön (0° - 359°)
        self.battery = 100.0  # başlangıç batarya %

        # CSV dosyasına yazma işlemi için başlıkları yazma
        self.csv_file = "telemetry_data.csv"
        with open(self.csv_file, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Time(s)", "Latitude", "Longitude", "Heading", "Battery", "Description"])

    def update_location_from_sensor(self):
        # Sensörden gelen verileri simüle edelim (gerçek sensör kodu burada yer alır)
        # Gerçek sensörle entegre etmek için: sensör_kütüphanesi.read_gps() gibi bir komut kullanılır
        self.latitude += random.uniform(0.00005, 0.00015)  # Konum biraz değişiyor
        self.longitude += random.uniform(0.00005, 0.00015)  # Konum biraz değişiyor

    def update_heading(self):
        # Yönü biraz değiştir (0-359 derece arası)
        self.heading = (self.heading + random.randint(-5, 5)) % 360

    def update_battery(self):
        # Batarya yavaş yavaş azalır
        if self.battery > 0:
            self.battery -= 0.05

    def get_status(self):
        return {
            "latitude": round(self.latitude, 6),
            "longitude": round(self.longitude, 6),
            "heading": round(self.heading),
            "battery": round(self.battery, 2)
        }

    def log_to_csv(self, status):
        # Zaman damgası
        time_stamp = round(time.time(), 2)
        
        # Açıklama
        description = f"Konum: {status['latitude']} N, {status['longitude']} E, Yön: {status['heading']}°, Batarya: {status['battery']}%"
        
        # Veriyi CSV dosyasına yazma
        with open(self.csv_file, mode="a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([time_stamp, status["latitude"], status["longitude"], status["heading"], status["battery"], description])

    def run(self):
        try:
            while True:
                # Sensörden konumu güncelle
                self.update_location_from_sensor()

                # Durumları güncelle
                self.update_heading()
                self.update_battery()

                # Durumu al
                status = self.get_status()

                # Durumu ekrana yazdır
                print(f"""
                 Konum       : {status['latitude']} N, {status['longitude']} E
                 Yön (derece): {status['heading']}°
                 Batarya     : {status['battery']}%
                """)

                # Durumu CSV dosyasına kaydet
                self.log_to_csv(status)

                # 2 saniye bekle
                time.sleep(2)
                
        except KeyboardInterrupt:
            print("Simülasyon durdu.")

if __name__ == "__main__":
    simulator = VehicleStatusSimulator()
    simulator.run()