CSV Dosyasına Yazma:

Simülasyon her 2 saniyede bir aracın durumu (konum, yön, batarya) alınıp ekrana yazdırılır ve aynı zamanda telemetry_data.csv dosyasına kaydedilir.

CSV dosyasına yazılan başlıklar:

Zaman (Time(s)): Simülasyonun hangi saniyede verinin toplandığını gösterir.

Konum (Latitude, Longitude): Aracın konumu.

Yön (Heading): Aracın yönü.

Batarya (Battery): Aracın batarya seviyesi.

Açıklama (Description): Durumun açıklaması.

Zaman Damgası:

Her kaydedilen veri ile birlikte, o anki zaman da kaydedilir (Unix zaman formatında).

Her Güncellemede Verilerin Ekrana Basılması:

Simülasyon çalışırken her 2 saniyede bir güncellenen veriler ekranda görüntülenir.

CSV Dosyasına Sürekli Yazma:

Her güncellenen veriler, baştan sona kaydedilmek yerine her bir güncelleme için dosyaya yazılır. Bu sayede geçmiş veriler kaybolmaz.
