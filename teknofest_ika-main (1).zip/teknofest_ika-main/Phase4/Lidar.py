#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import random

class SensorFusionNode(Node):
    def __init__(self):
        super().__init__('sensor_fusion_node')

        # Publisher: Birleştirilmiş engel mesafesi
        self.fused_pub = self.create_publisher(Float32, 'fused_obstacle_distance', 10)

        # Subscriberlara gerek yok, simülasyon için rastgele veri kullanılıyor
        self.timer = self.create_timer(0.5, self.sensor_callback)

    def sensor_callback(self):
        # Simüle edilmiş sensör verileri (Lidar ve Ultrasonik)
        lidar_distance = random.uniform(0.5, 5.0)  # Lidar verisi (metre)
        ultrasonic_distance = random.uniform(0.3, 5.5)  # Ultrasonik verisi (metre)

        # Sensor fusion: Basit ağırlıklı ortalama
        # Lidar'a %70, Ultrasonik'e %30 ağırlık verildi
        fused_distance = (0.7 * lidar_distance) + (0.3 * ultrasonic_distance)

        # Yayınla
        msg = Float32()
        msg.data = fused_distance
        self.fused_pub.publish(msg)

        # Terminal çıktısı
        self.get_logger().info(f'LIDAR: {lidar_distance:.2f} m, Ultrasonik: {ultrasonic_distance:.2f} m, Fused: {fused_distance:.2f} m')

def main(args=None):
    rclpy.init(args=args)
    node = SensorFusionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node durduruldu')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
