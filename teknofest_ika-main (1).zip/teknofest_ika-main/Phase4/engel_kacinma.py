#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String

# Bu eşik değeri, tank ile engel arasındaki güvenli mesafeyi belirler
SAFE_DISTANCE = 1.2  # metre

class ObstacleAvoidanceNode(Node):
    def __init__(self):
        super().__init__('obstacle_avoidance_node')

        self.subscription = self.create_subscription(
            Float32,
            'fused_obstacle_distance',
            self.obstacle_callback,
            10
        )
        self.command_pub = self.create_publisher(String, 'movement_command', 10)
        self.get_logger().info("Engel kaçış düğümü başlatıldı.")

    def obstacle_callback(self, msg):
        distance = msg.data
        decision = String()

        if distance < SAFE_DISTANCE:
            # Engelle çok yakın - rastgele sağ/sol sapma
            turn_direction = "LEFT" if distance % 2 < 1 else "RIGHT"
            decision.data = f'TURN_{turn_direction}'
            self.get_logger().warn(f"Engel {distance:.2f} m yakınında! {turn_direction} yönüne kaçınılıyor.")
        else:
            decision.data = 'FORWARD'
            self.get_logger().info(f"Mesafe güvenli: {distance:.2f} m, düz devam.")

        self.command_pub.publish(decision)

def main(args=None):
    rclpy.init(args=args)
    node = ObstacleAvoidanceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Engel kaçış düğümü durduruldu.')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
