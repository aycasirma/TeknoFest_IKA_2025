Kullanım Kılavuzu:

1. motor_controller.py dosyasını çalıştırın (Python 3 ile).
2. Komut istemine aşağıdaki komutları yazabilirsiniz:
   - FORWARD(1): İleri hareket
   - BACKWARD(2): Geri hareket
   - LEFT(3): Sola dön
   - RIGHT(4): Sağa dön
   - STOP(5): Motorları durdur

3. Her komut sonrası hareketler CSV dosyasına kaydedilecektir (motor_controller.csv).

4. CSV Dosyasındaki her satır:
   - Zaman (Time(s)) - Komutun hangi saniyede gerçekleştiği
   - Komut (Command) - Hangi hareket yapıldığı
   - Motor pin durumları (IN1, IN2, IN3, IN4)
   - Açıklama (Description) - Hangi hareket yapıldığına dair açıklama

5. Mekanik ekip, bu CSV dosyasını SolidWorks’teki Motion Study ile kullanarak robotun her hareketini simüle edebilir.

Not: Eğer bir sorun oluşursa, lütfen benimle iletişime geçin.
