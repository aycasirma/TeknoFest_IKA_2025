import time
import csv

# Simülasyon için GPIO sınıfı
class GPIO:
    OUT = 0
    HIGH = 1
    LOW = 0
    BOARD = 1
    BCM = 2

    def __init__(self):
        self.pins = {}
        self.mode = None

    def setmode(self, mode):
        self.mode = mode
        print(f"Pin numaralandırma modu: {mode}")

    def setup(self, pin, mode):
        self.pins[pin] = self.LOW
        print(f"Pin {pin} çıkış olarak ayarlandı.")

    def output(self, pin, state):
        if pin in self.pins:
            self.pins[pin] = state
            print(f"Pin {pin} {'YANDI' if state == self.HIGH else 'SÖNDÜ'}")
        else:
            print(f"Pin {pin} daha önce tanımlanmadı.")

    def cleanup(self):
        print("GPIO temizlendi.")

# GPIO'yu simülasyon olarak başlat
GPIO = GPIO()

class MotorController:
    def __init__(self):
        print("Motor Controller başlatıldı (simülasyon modu).")

        # Motor pinlerini tanımla
        self.IN1 = 17
        self.IN2 = 18
        self.IN3 = 22
        self.IN4 = 23

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.IN1, GPIO.OUT)
        GPIO.setup(self.IN2, GPIO.OUT)
        GPIO.setup(self.IN3, GPIO.OUT)
        GPIO.setup(self.IN4, GPIO.OUT)

        # CSV log dosyasını başlat
        self.log_file = "motor_controller.csv"
        self.fieldnames = ["Time(s)", "Command", "IN1", "IN2", "IN3", "IN4", "Description"]
        with open(self.log_file, mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self.fieldnames)
            writer.writeheader()

    def log_move(self, command, description):
        # Komutları logla (zaman, komut, motor pin durumu)
        with open(self.log_file, mode='a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self.fieldnames)
            current_time = time.time()
            writer.writerow({
                "Time(s)": round(current_time, 2),
                "Command": command,
                "IN1": self.IN1,
                "IN2": self.IN2,
                "IN3": self.IN3,
                "IN4": self.IN4,
                "Description": description
            })

    def move_forward(self):
        GPIO.output(self.IN1, GPIO.HIGH)
        GPIO.output(self.IN2, GPIO.LOW)
        GPIO.output(self.IN3, GPIO.HIGH)
        GPIO.output(self.IN4, GPIO.LOW)
        print("İleri gidiyor.")
        self.log_move(1, "İleri hareket")

    def move_backward(self):
        GPIO.output(self.IN1, GPIO.LOW)
        GPIO.output(self.IN2, GPIO.HIGH)
        GPIO.output(self.IN3, GPIO.LOW)
        GPIO.output(self.IN4, GPIO.HIGH)
        print("Geri gidiyor.")
        self.log_move(2, "Geri hareket")

    def turn_left(self):
        GPIO.output(self.IN1, GPIO.LOW)
        GPIO.output(self.IN2, GPIO.HIGH)
        GPIO.output(self.IN3, GPIO.HIGH)
        GPIO.output(self.IN4, GPIO.LOW)
        print("Sola dönüyor.")
        self.log_move(3, "Sola dön")

    def turn_right(self):
        GPIO.output(self.IN1, GPIO.HIGH)
        GPIO.output(self.IN2, GPIO.LOW)
        GPIO.output(self.IN3, GPIO.LOW)
        GPIO.output(self.IN4, GPIO.HIGH)
        print("Sağa dönüyor.")
        self.log_move(4, "Sağa dön")

    def stop_motors(self):
        GPIO.output(self.IN1, GPIO.LOW)
        GPIO.output(self.IN2, GPIO.LOW)
        GPIO.output(self.IN3, GPIO.LOW)
        GPIO.output(self.IN4, GPIO.LOW)
        print("Motorlar durdu.")
        self.log_move(5, "Durdur")

    def run(self):
        try:
            while True:
                command = input("Komut gir (FORWARD(1)/BACKWARD(2)/LEFT(3)/RIGHT(4)/STOP(5)): ").upper()
                print(f"Komut alındı: {command}")

                if command == "1":
                    self.move_forward()
                elif command == "2":
                    self.move_backward()
                elif command == "3":
                    self.turn_left()
                elif command == "4":
                    self.turn_right()
                elif command == "5":
                    self.stop_motors()
                else:
                    print("Geçersiz komut.")
        except KeyboardInterrupt:
            print("\nÇıkılıyor...")
        finally:
            GPIO.cleanup()

if __name__ == "__main__":
    controller = MotorController()
    controller.run()
