#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import cv2
import numpy as np

class DummyCameraNode(Node):
    def __init__(self):
        super().__init__('dummy_camera_node')

        self.publisher_ = self.create_publisher(Image, 'camera/image_raw', 10)
        self.bridge = CvBridge()
        self.timer = self.create_timer(0.1, self.publish_dummy_image)  # 10 Hz
        self.get_logger().info("Dummy Camera Node started.")

    def publish_dummy_image(self):
        # Create a dummy image (black image with a red square moving around)
        img = np.zeros((480, 640, 3), dtype=np.uint8)

        x = np.random.randint(100, 540)
        y = np.random.randint(100, 380)
        cv2.rectangle(img, (x, y), (x+50, y+50), (0, 0, 255), -1)

        # Convert to ROS Image message
        msg = self.bridge.cv2_to_imgmsg(img, encoding="bgr8")
        self.publisher_.publish(msg)

        self.get_logger().info("Dummy image published.")

def main(args=None):
    rclpy.init(args=args)
    node = DummyCameraNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Dummy camera node stopped.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
